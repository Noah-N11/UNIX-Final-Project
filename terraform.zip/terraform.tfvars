project_id = "cop3304-fall2026"

region = "us-central1"
